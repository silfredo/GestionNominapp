/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tecnologico.view;

/**
 *
 * @author Silfredo Antonio Blanco Monroy
 * @author Nicky Meza
 * @author Esteban Garcia
 * @author Isaias Vargas
 * @author Luis Fabra
 * 
 */
public class EditarEmpleadoMenu {
    
}
