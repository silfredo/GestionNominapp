package com.tecnologico.view;

import com.tecnologico.controller.EmpleadoController;

/**
 *
 * @author Silfredo Antonio Blanco Monroy
 * @author Nicky Meza
 * @author Esteban Garcia
 * @author Isaias Vargas
 * @author Luis Fabra
 * 
 */
public class LiquidarEmpleadoMenu extends EmpleadoController {
    
}
